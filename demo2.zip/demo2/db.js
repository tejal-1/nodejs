const mongoose = require('mongoose');
mongoose.connect('mongodb://localhost:27017/testing', {
    useNewUrlParser: true,

}, (err) => {
    if (!err) {
        console.log("MongoDB Connected...");

    } else {
        console.log("Error");
    }
});
module.exports = mongoose