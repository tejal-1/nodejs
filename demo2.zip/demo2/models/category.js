const mongoose = require('mongoose'),
    Schema = mongoose.Schema;
var categorySchema = Schema({
    name: {
        type: String,
        required: true
    },
    sequence: {
        type: Number
    },
});
var categoryData = mongoose.model('category', categorySchema);
module.exports = {
    categoryData
}