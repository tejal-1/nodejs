const mongoose = require('mongoose'),
    Schema = mongoose.Schema,
    ObjectId = mongoose.ObjectId;


var productSchema = Schema({
    name: {
        type: String,
        required: true
    },
    details: {
        type: String
    },
    amount: {
        type: Number
    },
    quantity: {
        type: Number

    },
    category: {
        type: Schema.Types.ObjectId,
        ref: "category",
        required: true
    },
    productSize: {
        type: Schema.Types.ObjectId,
        ref: "size"
    }
});
var productData = mongoose.model('products', productSchema);
module.exports = {
    productData
}