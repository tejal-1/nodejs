const mongoose = require('mongoose'),
    Schema = mongoose.Schema,
    ObjectId = mongoose.ObjectId;


var sizeSchema = Schema({
    name: {
        type: String,
        required: true
    },
    details: {
        type: String
    }

});
var sizeData = mongoose.model('size', sizeSchema);
module.exports = {
    sizeData
}