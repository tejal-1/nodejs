var { sizeData } = require('../models/size.js');

exports.deleteSizeData = function (req, res) {
    sizeData.deleteOne(
        {
            _id: req.body.id
        },
        (err, sizeDelete) => {
            if (!err) {
                res.status(200).send({
                    message: 'Delete Successfully'
                })
            } else {
                console.log(err)
            }
        }
    )
}