var { sizeData } = require('../models/size.js');
exports.saveData = function (req, res) {
    console.log("req==========", req)
    var data = {
        name: req.body.name,
        details: req.body.details
    }
    console.log("data", data)
    const size = new sizeData(data)
    size.save((err, savesize) => {
        if (!err) {
            res.status(200).send({
                message: 'Save Successfully'
            })
        } else {
            console.log(err);
        }
    })
}