

var { categoryData } = require('../models/category.js');

exports.updateCategoryData = function (req, res) {
    var updatedata = {
        $set: {
            name: req.body.name,
            sequence: req.body.sequence
        }
    }
    categoryData.findOneAndUpdate(
        {
            _id: req.body.id
        },
        updatedata,
        {
            new: true
        },
        (err, update) => {
            if (!err) {
                res.status(200).send({
                    message: 'Update Successfully'
                })
            }else{
                console.log(err)
            }
        }
    )
}