

var { productData } = require('../models/products.js');
var { categoryData } = require('../models/category.js');
exports.getAllProductData = function (req, res) {
    productData.find(
        {})
        .populate("category").exec((err, product) => {
            if (!err) {
                res.status(200).send({
                    product
                })
            } else {
                console.log(err)
            }
        })
}