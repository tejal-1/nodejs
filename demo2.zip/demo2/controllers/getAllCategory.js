

var { categoryData } = require('../models/category.js');

exports.getAllCategoryData = function (req, res) {
    categoryData.find(
   {},
        (err, product) => {
            if (!err) {
                res.status(200).send({
                    product
                })
            }else{
                console.log(err)
            }
        }
    )
}