var {
    productData
} = require('../models/products.js');

exports.updateProductData = function (req, res) {
    var updatedata = {
        $set: {
            name: req.body.name,
            details: req.body.details,
            amount: req.body.amount,
            quantity: req.body.quantity
        }
    }
    productData.findOneAndUpdate({
            _id: req.body.id
        },
        updatedata, {
            new: true
        },
        (err, update) => {
            if (!err) {
                res.status(200).send({
                    message: 'Update Successfully'
                })
            } else {
                console.log(err)
            }
        }
    )
}