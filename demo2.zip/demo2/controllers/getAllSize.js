var { sizeData } = require('../models/size.js');

exports.getAllsizeData = function (req, res) {
    sizeData.find(
        {},
        (err, size) => {
            if (!err) {
                res.status(200).send({
                    size
                })
            } else {
                console.log(err)
            }
        }
    )
}