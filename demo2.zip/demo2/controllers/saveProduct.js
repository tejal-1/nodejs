

var { productData } = require('../models/products.js');

exports.saveData = function (req, res) {
    console.log("req==========", req)
    var data = {
        name: req.body.name,
        details: req.body.details,
        amount: req.body.amount,
        quantity: req.body.quantity,
        category: req.body.category,
        productSize:req.body.size
    }
    console.log("data", data)
    const product = new productData(data)
    product.save((err, saveproduct) => {
        if (!err) {
            res.status(200).send({
                message: 'Save Successfully'
            })
        } else {
            console.log(err);
        }
    })
}