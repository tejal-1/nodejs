var { sizeData } = require('../models/size.js');
exports.updateSizeData = function (req, res) {
    console.log("req==========", req.body)
    var updatedata = {
        $set: {
            name: req.body.name,
            details: req.body.details
        }
    }
    // console.log("data", data)
    sizeData.findOneAndUpdate(
        {
            _id: req.body.id
        },
        updatedata,
        {
            new: true
        },
        (err, update) => {
            if (!err) {
                res.status(200).send({
                    message: 'Update Successfully'
                })
            } else {
                console.log(err)
            }
        }
    )
}