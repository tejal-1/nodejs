
var { categoryData } = require('../models/category.js');

exports.deleteCategoryData = function (req, res) {
    categoryData.deleteOne(
   {
    _id: req.body.id
   },
        (err, productDelete) => {
            if (!err) {
                res.status(200).send({
                    message: 'Delete Successfully'
                })
            }else{
                console.log(err)
            }
        }
    )
}