

var { productData } = require('../models/products.js');

exports.deleteProductData = function (req, res) {
    productData.deleteOne(
   {
    _id: req.body.id
   },
        (err, productDelete) => {
            if (!err) {
                res.status(200).send({
                    message: 'Delete Successfully'
                })
            }else{
                console.log(err)
            }
        }
    )
}