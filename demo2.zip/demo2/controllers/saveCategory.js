

var { categoryData } = require('../models/category.js');

exports.saveData = function (req, res) {
    console.log("req==========", req)
    var data = {
        name: req.body.name,
        sequence: req.body.sequence
    }
    console.log("data", data)
    const category = new categoryData(data)
    category.save((err,savecategory ) => {
        if (!err) {
            res.status(200).send({
                message:'Save Successfully'
            })
        } else {
            console.log(err);
        }
    })
}