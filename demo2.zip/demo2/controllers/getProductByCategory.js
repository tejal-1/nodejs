const mongoose = require('mongoose'),ObjectId=mongoose.ObjectId;
var { categoryData } = require('../models/category.js');
var { productData } = require('../models/products.js');
var async = require("async");
var _ = require('lodash');

exports.getAllProductByCategory = function (req, res) {
    let data = {
        limit: req.body.limit,
        page: req.body.page,
        category: req.body.category
    }
    var limit = parseInt(data.limit ? data.limit : 5)
    var page = data.page ? data.page - 1 : 0
    var pagesize = limit * page
    productData.aggregate([
        {
            $facet: {
                result: [
                    {
                        $match: {
                            category: mongoose.Types.ObjectId(data.category)
                        }
                    },
                    {
                        $skip: pagesize
                    },
                    {
                        $limit: limit
                    }
                ],
                count: [
                    {
                        $match: {
                            category: mongoose.Types.ObjectId(data.category)
                        }
                    },
                    {
                        $count: "count"
                    }
                ]
            }
        }
    ], (err, product) => {
        if (!err) {
            if (product &&
                !_.isEmpty(product) &&
                product[0].result.length > 0) {
                res.status(200).send(
                    {
                        result: product[0].result,
                        count: product[0].count[0].count
                    })
            }
        } else {
            console.log("err")
        }
    })
   
}