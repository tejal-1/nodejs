const express = require('express');
const bodyParser = require('body-parser');

const app = express();

app.use(bodyParser.json());
const saveProducts = require('../controllers/saveProduct')
const updateProduct = require('../controllers/updateProduct')
const AllProduct = require('../controllers/getAllProduct')
const deleteProduct = require('../controllers/deleteProduct')
const saveCategory = require('../controllers/saveCategory')
const updateCategory = require('../controllers/updateCategory')
const AllCategory = require('../controllers/getAllCategory')
const deleteCategory = require('../controllers/deleteCategory')
const getProductByCategory = require('../controllers/getProductByCategory')
const saveSize = require('../controllers/saveSize')
const updateSize = require('../controllers/updateSize')
const AllSize = require('../controllers/getAllSize')
const deleteSize = require('../controllers/deleteSize')

//testing api
app.get('/test', (req, res) => {
    res.send({
        status: 200,
        message: 'app is working'
    })
})
//All crud
app.post('/product/save', (req, res) => {
    saveProducts.saveData(req, res)
})
app.put('/product/update', (req, res) => {
    updateProduct.updateProductData(req, res)
})
app.get('/product/getAll', (req, res) => {
    AllProduct.getAllProductData(req, res)
})
app.delete('/product/delete', (req, res) => {
    deleteProduct.deleteProductData(req, res)
})
app.post('/category/save', (req, res) => {
    saveCategory.saveData(req, res)
})
app.put('/category/update', (req, res) => {
    updateCategory.updateCategoryData(req, res)
})
app.get('/category/getAll', (req, res) => {
    AllCategory.getAllCategoryData(req, res)
})
app.delete('/category/delete', (req, res) => {
    deleteCategory.deleteCategoryData(req, res)
})
app.post('/allProduct', (req, res) => {
    getProductByCategory.getAllProductByCategory(req, res)
})
app.post('/size/save', (req, res) => {
    saveSize.saveData(req, res)
})
app.put('/size/update', (req, res) => {
    updateSize.updateSizeData(req, res)
})
app.get('/size/getAll', (req, res) => {
    AllSize.getAllSizeData(req, res)
})
app.delete('/size/delete', (req, res) => {
    deleteSize.deleteSizeData(req, res)
})

module.exports = app;